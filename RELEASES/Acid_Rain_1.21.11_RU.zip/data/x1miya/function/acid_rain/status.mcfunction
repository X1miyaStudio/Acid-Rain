execute if score #active x1miya.ar matches 1 run tellraw @s {"text":"Кислотный дождь активен.","color":"dark_green"}
execute unless score #active x1miya.ar matches 1 if score #raining x1miya.ar matches 1 run tellraw @s {"text":"Идёт обычный дождь.","color":"aqua"}
execute unless score #raining x1miya.ar matches 1 run tellraw @s {"text":"Дождя нет.","color":"gray"}
tellraw @s {"text":"Шанс кислотного дождя при начале дождя: 25%.","color":"gray"}
scoreboard players set #protected x1miya.ar 0
execute if items entity @s armor.feet minecraft:iron_boots[minecraft:custom_data~{x1miya_acid_rain_gear:"chem"}] run scoreboard players add #protected x1miya.ar 1
execute if items entity @s armor.legs minecraft:iron_leggings[minecraft:custom_data~{x1miya_acid_rain_gear:"chem"}] run scoreboard players add #protected x1miya.ar 1
execute if items entity @s armor.chest minecraft:iron_chestplate[minecraft:custom_data~{x1miya_acid_rain_gear:"chem"}] run scoreboard players add #protected x1miya.ar 1
execute if items entity @s armor.head minecraft:iron_helmet[minecraft:custom_data~{x1miya_acid_rain_gear:"chem"}] run scoreboard players add #protected x1miya.ar 1
execute if score #protected x1miya.ar matches 4 run tellraw @s {"text":"Обнаружен полный комплект химзащиты.","color":"green"}
execute unless score #protected x1miya.ar matches 4 run tellraw @s [{"text":"Обнаружено частей химзащиты: ","color":"yellow"},{"score":{"name":"#protected","objective":"x1miya.ar"}},{"text":"/4","color":"yellow"}]
tellraw @s {"text":"Химзащита использует счётчик коррозии; Прочность снижает шанс коррозии. Полосы прочности показывают состояние.","color":"gray"}
function x1miya:acid_rain/debug_armor
