scoreboard players set #active x1miya.ar 0
title @a actionbar {"text":"Начался обычный дождь. Кислоты нет","color":"aqua"}
playsound minecraft:weather.rain.above weather @a ~ ~ ~ 0.25 1.2
