function x1miya:acid_rain/damage_armor
function x1miya:acid_rain/debug_armor
tellraw @s {"text":"Применён один шаг коррозии химзащиты.","color":"yellow"}
